export const environment = {
  production: true,  
  HOST: 'http://TU_IP_PUBLICA/mediapp-backend',
  TOKEN_AUTH_USERNAME: 'mitomediapp',
  TOKEN_AUTH_PASSWORD: 'mito89codex',
  TOKEN_NAME: 'access_token',
  REINTENTOS: 3,
};
