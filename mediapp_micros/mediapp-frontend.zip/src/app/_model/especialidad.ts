export class Especialidad {
    idEspecialidad: number;
    nombre: string;
}